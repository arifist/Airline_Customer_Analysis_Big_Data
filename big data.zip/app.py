from flask import Flask, render_template, request,flash
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Flash mesajlarını kullanmak için gerekli

import sklearn
print(sklearn.__version__)
# Modelimizi yükleyelim (modeli daha önce kaydetmiş olduğunuzu varsayıyorum)
model = joblib.load('model.pkl')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Formdan gelen verileri alalım
        input_data = {
            'Inflight_wifi_service': int(request.form['Inflight_wifi_service']),
            'Departure/Arrival_time_convenient': int(request.form['Departure/Arrival_time_convenient']),
            'Ease_of_Online_booking': int(request.form['Ease_of_Online_booking']),
            'Gate_location': int(request.form['Gate_location']),
            'Food_and_drink': int(request.form['Food_and_drink']),
            'Online_boarding': int(request.form['Online_boarding']),
            'Seat_comfort': int(request.form['Seat_comfort']),
            'Inflight_entertainment': int(request.form['Inflight_entertainment']),
            'On-board_service': int(request.form['On-board_service']),
            'Leg_room_service': int(request.form['Leg_room_service']),
            'Baggage_handling': int(request.form['Baggage_handling']),
            'Checkin_service': int(request.form['Checkin_service']),
            'Inflight_service': int(request.form['Inflight_service']),
            'Cleanliness': int(request.form['Cleanliness'])
        }

        # Veriyi dataframe'e dönüştürelim
        input_df = pd.DataFrame(input_data, index=[0])

        # Tahmin yapalım
        prediction = model.predict(input_df)

        # Sonucu belirleyelim
        if prediction[0] == 0:
            result = "Bu müşterinin memnuniyet puanı düşük."
            flash("Bu müşterinin memnuniyet puanı düşük.", 'danger')  # Kırmızı bildirim gönder

        else:
            result = "Bu müşterinin memnuniyet puanı yüksek."
            flash("Bu müşterinin memnuniyet puanı yüksek.", 'success')  # Kırmızı bildirim gönder

        
        return render_template('index.html', result=result)

    return render_template('index.html', result=None)

if __name__ == '__main__':
    app.run(debug=True)
