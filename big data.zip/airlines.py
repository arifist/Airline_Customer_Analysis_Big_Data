import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
import joblib


# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
#preprocessing

# df = pd.read_excel("airline_clnd.xlsx")

# df["satisfaction"] = df["satisfaction"].map({"neutral or dissatisfied": 0, "satisfied": 1})

# df["Gender"] = df["Gender"].map({"Male": 0, "Female": 1})

# df["Customer_Type"] = df["Customer_Type"].map({"Loyal Customer": 0, "disloyal Customer": 1})

# df["Type_of_Travel"] = df["Type_of_Travel"].map({"Personal Travel": 0, "Business travel": 1})

# df["Class"] = df["Class"].map({"Eco Plus": 0,"Eco": 0, "Business": 1})


# df.to_excel("guncellenmis_airline_clnd.xlsx", index=False)

df = pd.read_excel("guncellenmis_airline_clnd.xlsx")

#colab
# drive.mount('/content/drive')
# df=pd.read_csv('/content/drive/MyDrive/Sentiment/guncellenmis_airline_clnd.xlsx')


# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
#ozellik onemi analizi

# X = df.drop(columns=["satisfaction"])
X = df[['Inflight_wifi_service', 'Departure/Arrival_time_convenient', 'Ease_of_Online_booking', 
          'Gate_location', 'Food_and_drink', 'Online_boarding', 'Seat_comfort', 
          'Inflight_entertainment', 'On-board_service', 'Leg_room_service', 'Baggage_handling', 
          'Checkin_service', 'Inflight_service', 'Cleanliness']]
y = df["satisfaction"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

feature_importances = model.feature_importances_

print("Özelliklerin Genel Memnuniyet Puanına Katkısı:")
for i, feature in enumerate(X.columns):
    print(f"{feature}: {feature_importances[i]}")


feature_importance_df = pd.DataFrame({"Feature": X.columns, "Importance": feature_importances})
feature_importance_df = feature_importance_df.sort_values(by="Importance", ascending=False)

sns.set_style("whitegrid")

plt.figure(figsize=(10, 8))
plt.pie(feature_importance_df["Importance"], labels=feature_importance_df["Feature"], autopct='%1.1f%%', startangle=140, colors=sns.color_palette("muted"))
plt.axis('equal')
plt.title('Özelliklerin Genel Memnuniyet Puanına Katkısı')
plt.show()


# Çubuk grafiği oluşturma
plt.figure(figsize=(10, 8))
sns.barplot(x="Importance", y="Feature", data=feature_importance_df, palette="viridis")
plt.title('Özelliklerin Genel Memnuniyet Puanına Katkısı')
plt.xlabel('Önem Derecesi')
plt.ylabel('Özellikler')
plt.show()
    

# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
# # sadık ve sadık olmayan sayısı


# loyale = df[df['Customer_Type'] == 0].shape[0]
# disloyale = df[df['Customer_Type'] == 1].shape[0]

# #olumlu oy kullanan kadın
# disloyale_count = df[(df['Customer_Type'] == 1) & (df['satisfaction'] == 1)].shape[0]
# loyale_count = df[(df['Customer_Type'] == 0) & (df['satisfaction'] == 1)].shape[0]

# print("Sadik sayısı:", loyale)
# print("Sadik olmayan olumlu oy kullananların sayısı:", loyale_count)

# print("Sadik olmayan sayısı:", disloyale)
# print("Sadik olmayan olumlu oy kullananların sayısı:", disloyale_count)


# # Customer_Tyoe'a göre grupla ve ortalama memnuniyet düzeylerini hesapla
# customer_type_satisfaction = df.groupby("Customer_Type")["satisfaction"].mean()

# # Sonuçları yazdır
# print(customer_type_satisfaction)



# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
# # model egitimi


X = df[['Inflight_wifi_service', 'Departure/Arrival_time_convenient', 'Ease_of_Online_booking', 
          'Gate_location', 'Food_and_drink', 'Online_boarding', 'Seat_comfort', 
          'Inflight_entertainment', 'On-board_service', 'Leg_room_service', 'Baggage_handling', 
          'Checkin_service', 'Inflight_service', 'Cleanliness']]
y = df['satisfaction']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Doğruluk: {:.2f}%".format(accuracy * 100))



sample_input = {
    'Inflight_wifi_service': 1,
    'Departure/Arrival_time_convenient': 1,
    'Ease_of_Online_booking': 1,
    'Gate_location': 2,
    'Food_and_drink': 1,
    'Online_boarding': 1,
    'Seat_comfort': 1,
    'Inflight_entertainment': 2,
    'On-board_service': 2,
    'Leg_room_service': 2,
    'Baggage_handling': 2,
    'Checkin_service': 1,
    'Inflight_service': 2,
    'Cleanliness': 3
}

sample_input_df = pd.DataFrame(sample_input, index=[0])

satisfaction_prediction = model.predict(sample_input_df)

if satisfaction_prediction[0] == 0:
    print("Bu müşterinin memnuniyet puanı düşük.")
else:
    print("Bu müşterinin memnuniyet puanı yüksek.")
    
# Modeli kaydet
joblib.dump(model, 'model.pkl')

print("Model başarıyla eğitildi ve kaydedildi!")


from sklearn.metrics import accuracy_score, confusion_matrix

# Karışıklık matrisi hesaplama
conf_matrix = confusion_matrix(y_test, y_pred)

# Karışıklık matrisini görselleştirme
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=['Düşük Memnuniyet', 'Yüksek Memnuniyet'], yticklabels=['Düşük Memnuniyet', 'Yüksek Memnuniyet'])
plt.xlabel('Tahmin Edilen')
plt.ylabel('Gerçek')
plt.title(f'Karışıklık Matrisi (Doğruluk: {accuracy * 100:.2f}%)')
plt.show()

# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------




# kadın- erkek analiz
# from scipy.stats import ttest_ind

# Cinsiyetlere göre memnuniyeti ayır
# male_satisfaction = df[df['Gender'] == 0]['satisfaction']
# female_satisfaction = df[df['Gender'] == 1]['satisfaction']

# # T-testi yap
# t_statistic, p_value = ttest_ind(male_satisfaction, female_satisfaction)

# print("T-Statistic:", t_statistic)
# print("P-Value:", p_value)

# # Kadınların ve erkeklerin sayısı
# female_count = df[df['Gender'] == 1].shape[0]
# male_count = df[df['Gender'] == 0].shape[0]

# # Kadınların olumlu oy kullananların sayısı
# female_positive_count = df[(df['Gender'] == 1) & (df['satisfaction'] == 1)].shape[0]
# male_positive_count = df[(df['Gender'] == 0) & (df['satisfaction'] == 1)].shape[0]

# print("Kadınların sayısı:", female_count)
# print("Kadınların olumlu oy kullananların sayısı:", female_positive_count)

# print("Erkeklerin sayısı:", male_count)
# print("Erkeklerin olumlu oy kullananların sayısı:", male_positive_count)

# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------


# Bağımsız değişkenler ve bağımlı değişken arasında ayrım yapın
# X = df[["Gender"]]
# y = df["satisfaction"]  # Bağımlı değişken (memnuniyet)

# # Eğitim ve test veri kümelerini oluşturun
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Destek vektör makinesi (SVM) modelini oluşturun
# model = SVC(kernel='linear', random_state=42)  # Lineer çekirdek kullanıldı, farklı çekirdekler deneyebilirsiniz

# # Modeli eğitin
# model.fit(X_train, y_train)

# # Modeli kullanarak tahmin yapın
# y_pred = model.predict(X_test)

# # Modelin performansını değerlendirin
# accuracy = accuracy_score(y_test, y_pred)
# print("Model Accuracy:", accuracy)

# # Sınıflandırma raporu
# print(classification_report(y_test, y_pred))





